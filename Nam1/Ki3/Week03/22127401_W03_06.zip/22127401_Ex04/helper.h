#include <stdio.h>

int interpolationSearch(FILE* file, int data);
