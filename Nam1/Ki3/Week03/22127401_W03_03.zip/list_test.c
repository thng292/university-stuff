#include "list.h"

#include <assert.h>
#include <stdio.h>

int main(void) { 
    List* list = List_Init();
    for (int i = 0; i < 100; i++) {
        List_Push(list, i);
    }
    assert(List_IsEmpty(list) == false);
    int count = 99;
    while (!List_IsEmpty(list)) {
        assert(List_Pop(list) == count--);
    }
    List_Clear(list);
    printf("ALL TEST PASSED!!!\n");
    return 0; 
}
