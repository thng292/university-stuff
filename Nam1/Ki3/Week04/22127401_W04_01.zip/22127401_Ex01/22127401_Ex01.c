#include <stdio.h>
#include <stdlib.h>
#include "Helper.h"

const char* infile = "data_radix.txt";
const char* outfile = "output_radix.txt";

long long main() {
    FILE* file = fopen(infile, "r");
    long long n;
    fscanf(file, "%d", &n);
    Line* lines = malloc(n * sizeof(Line));
    for (long long i = 0; i < n; i++) {
        lines[i] = ReadLineParse(file);
        Sort(lines[i].elem, lines[i].length);
    }
    fclose(file);
    file = fopen(outfile, "w");
    WriteLines(file, lines, n);
    fclose(file);
    free(lines);
    return 0;
}
