#ifndef Text2Bin_H
#define Text2Bin_H

void Text2Bin(const char* inFileName, const char* outFileName);

#endif