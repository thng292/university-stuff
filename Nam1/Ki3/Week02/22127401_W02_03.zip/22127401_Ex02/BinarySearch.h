#include <stdio.h>

int BinarySearch(int* arr, int length, int key);

int BinarySearchFile(FILE* file, int key);
