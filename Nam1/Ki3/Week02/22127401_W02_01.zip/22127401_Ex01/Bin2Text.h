#ifndef Bin2Text_H
#define Bin2Text_H

void Bin2Text(const char* inFileName, const char* outFileName);

#endif