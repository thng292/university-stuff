#include <stdbool.h>

bool isPadlindrome(int l, int r, char* s);
