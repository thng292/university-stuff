#include <stdbool.h>

typedef struct {
  int x;
  int y;
} Pos;

void knightTourInit(int board_size);

