unsigned long long Fibbonacci(int n);

long long X(int n);

long long Y(int n);

long long Xseries(int n);

long long C(int n, int k);

void toBinary(int x);

int sumOfDigits(int x);