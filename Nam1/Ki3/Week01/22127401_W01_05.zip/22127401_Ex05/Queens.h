#include <stdbool.h>

void NQueens(int board_size);
